# health-tourism
1. Create admin
2. Login as admin
3. Create city from
4. Create city to
5. Get all cities
6. Create hospital with city id
7. Create Health Care service
8. Get all hospitals
9. Get all health care services
10. Add health care service to hospital with uuid
11. Create Doctor with hospital id and healthcare service id and create user with doctor role
  While creating, add user to doctor.
12. Get all doctor
13. Create Hotel with id for city and room counts
14. Get all hotels
15. Create Plane with city id included and plane seats
16. Get all planes
17. Create Flight with city id's and plane id
18. Get all flight
19. Create patient and while creating, create user with patient role and add to patient
20. Get all patients(Admin auth)
21. Login for Patient
22. Patient lists the health services and get uuid for hospital
23. Patient lists doctors from hospital
24. Patient lists the appointments from the doctor selected
25. Creates appointment for the doctor with id's
26. Get all appointments
27. Get Patient with Appointments
28. Patient lists the hotels according to appointment city with rooms booking dates.
29. Patient creates booking for the available room on the date.
30. Get Flight specified with the route
31. Selects the seat and creates ticket
32. Login as doctor
33. When the day comes doctor creates examination record from appointment

## You can reach these endpoints from "Health Tourism.postman_collection.json" file.