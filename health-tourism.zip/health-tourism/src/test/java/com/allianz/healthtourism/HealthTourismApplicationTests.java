package com.allianz.healthtourism;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthTourismApplicationTests {

    @Test
    void contextLoads() {
    }

}
