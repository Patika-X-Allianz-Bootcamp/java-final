package com.allianz.healthtourism.model.responseDTO;

import com.allianz.healthtourism.util.BaseResponseDTO;

public class PersonResponseDTO extends BaseResponseDTO {
}
