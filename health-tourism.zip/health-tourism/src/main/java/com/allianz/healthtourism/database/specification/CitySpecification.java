package com.allianz.healthtourism.database.specification;

import com.allianz.healthtourism.database.entity.CityEntity;
import com.allianz.healthtourism.util.pageable.BaseSpecification;
import org.springframework.stereotype.Component;

@Component
public class CitySpecification extends BaseSpecification<CityEntity> {
}
