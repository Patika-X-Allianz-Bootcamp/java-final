package com.allianz.healthtourism.database.specification;

import com.allianz.healthtourism.database.entity.HospitalEntity;
import com.allianz.healthtourism.util.pageable.BaseSpecification;
import org.springframework.stereotype.Component;

@Component
public class HospitalSpecification extends BaseSpecification<HospitalEntity> {
}
