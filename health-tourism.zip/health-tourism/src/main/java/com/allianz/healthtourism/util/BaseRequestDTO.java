package com.allianz.healthtourism.util;

public class BaseRequestDTO {
}
