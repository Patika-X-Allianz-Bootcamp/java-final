package com.allianz.healthtourism.database.specification;

import com.allianz.healthtourism.database.entity.ExaminationRecordEntity;
import com.allianz.healthtourism.util.pageable.BaseSpecification;
import org.springframework.stereotype.Component;

@Component
public class ExaminationRecordSpecification extends BaseSpecification<ExaminationRecordEntity> {
}
