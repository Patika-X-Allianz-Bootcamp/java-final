package com.allianz.healthtourism.util.security;

import com.allianz.healthtourism.util.pageable.BaseSpecification;
import org.springframework.stereotype.Component;

@Component
public class UserSpecification extends BaseSpecification<UserEntity> {
}
