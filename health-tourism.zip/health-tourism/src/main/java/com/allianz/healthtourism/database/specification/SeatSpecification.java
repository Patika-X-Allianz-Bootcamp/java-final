package com.allianz.healthtourism.database.specification;

import com.allianz.healthtourism.database.entity.SeatEntity;
import com.allianz.healthtourism.util.pageable.BaseSpecification;
import org.springframework.stereotype.Component;

@Component
public class SeatSpecification extends BaseSpecification<SeatEntity> {
}
